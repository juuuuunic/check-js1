$(document).ready(function(){
	calendar_picker();
	checkbox_all();
	taxation_select();
	search_radio();
	search_radio2();
	input_file_make();

	lp_type1();
	lp_type2();
	lp_type3();
	lp_type4();
});

// Top btn Action
function topBtn(){
	var scrollTop = $(".top-btn");
	$(scrollTop).click(function() {
		$('html, body').animate({
			scrollTop: 0
		}, 800);
		return false;
	});
}



function hideExclude(excludeClass) {
	$(".dashboard__search__type").children().each(function() {
		$(this).hide();
	});
	$("." + excludeClass).show();
}


function ajaxLink(href,type,idx){
	$.ajax({
		type: type,
		url: href,
		data : idx,
		success : function(data) {
			$('body').find('.layerpop').remove().end().append(data);
			$('body').addClass('fixed');
		}
	});
}

function ajaxClose(a){
	$(a).fadeOut(500,function(){$(this).remove()});
	$('body').removeClass('fixed');
}

//es6
//select value show hide
function showDiv(target, element){
	document.getElementsByClassName(target)[0].style.display = element.value === target ? 'block' : 'none';
}

// toggle display
function toggleDisplay(element){
	let target = document.querySelector(element).style;
	(function(style) {
		style.display = style.display === 'block' ? '' : 'block';
	})(target);
}


// calendar picker
function calendar_picker(){
	if($("input[id^='calendar']").length !== 0) {
		$("input[id^='calendar']").each(function() {
			var _this = this.id;
			$('#'+_this).datepicker({
				dateFormat: "yy-mm-dd",
				prevText: '이전 달',
				nextText: '다음 달',
				monthNames: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
				monthNamesShort: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
				dayNames: [ '일','월','화','수','목','금','토' ],
				dayNamesShort: [ '일','월','화','수','목','금','토' ],
				dayNamesMin:  [ '일','월','화','수','목','금','토' ],
				showMonthAfterYear: true,
				changeMonth: true,
				changeYear: true,
				yearRange: "1900:",
				yearSuffix: '년'
			});
		});
	}
}

// input file
function input_file_make(){
	if($(".input-file").length !== 0) {
		(function($){
			var $fileBox = null;
			$(function() {
				init();
			})
			function init() {
				$fileBox = $('.input-file');
				fileLoad();
			}
			function fileLoad() {
				$.each($fileBox, function(idx){
					var $this = $fileBox.eq(idx),
						$btnUpload = $this.find('[type="file"]'),
						$label = $this.find('.file-label');

				$btnUpload.on('change', function() {
					var $target = $(this),
						fileName = $target.val(),
						$fileText = $target.siblings('.file-name');
					$fileText.val(fileName);
				})

				$btnUpload.on('focusin focusout', function(e) {
					e.type == 'focusin' ?
						$label.addClass('file-focus') : $label.removeClass('file-focus');
					})      
				})
			}
		})(jQuery);
	}
}

function table_select(){
	if($(".td__table-set2__select").length !== 0) {
		$(".td__table-set2__select").change(function() {
			var selectValue = $(this).val();
			if (selectValue == "target") {
				$(this).closest('tr').addClass('positive');
				$(this).closest('tr').removeClass('negative');
				$(this).closest('tr').removeClass('undefine');
			} else if (selectValue == "nontarget") {
				$(this).closest('tr').addClass('negative');
				$(this).closest('tr').removeClass('positive');
				$(this).closest('tr').removeClass('undefine');
			} else if (selectValue == "unclassified") {
				$(this).closest('tr').addClass('undefine');
				$(this).closest('tr').removeClass('positive');
				$(this).closest('tr').removeClass('negative');
			}
		});
	}
}

function checkbox_all(){
	if($(".parents-check").length !== 0) {
		$( '.parents-check' ).click( function() {
			$( '.child-check' ).prop( 'checked', this.checked );
		} );
	}
}

function taxation_select(){
	if($(".taxation-change").length !== 0) {
		$(".taxation-change").change(function() {
			var selectValue = $(this).val();
			if (selectValue == "etc") {
				$('.hidden').addClass('active');
			} else {
				$('.hidden').removeClass('active');
			}
		});
	}
}

function popupType1(urlLink,w,h){
	var url = urlLink;
	var name = "";
	var option = "width = " + w + ", height = " + h + ", top = 100, left = 200, location = no";
	window.open(url, name, option);
}

function search_radio(){
	if($(".search-hidden").length !== 0) {
		hideExclude("change-day");

		$("input[name=search_radio]").change(function() {
			var radioValue = $(this).val();
			if (radioValue == "day") {
				hideExclude("change-day");
			} else if (radioValue == "month") {
				hideExclude("change-month");
			} else if (radioValue == "quarter") {
				hideExclude("change-quarter");
			}
		});
		
		var checkCnt = $("input[name=search_radio]:checked").length;
		if (checkCnt == 0) {
			$("input[name=search_radio]").eq(0).attr("checked", true);
		}
	}
}

function hideExclude(excludeClass) {
	$(".search-hidden").children().each(function() {
		$(this).hide();
	});
	$("." + excludeClass).show();
}

function search_radio2(){
	if($(".radio-hidden").length !== 0) {

		$("input[name=radioSetting]").change(function() {
			var radioValue = $(this).val();

			if (radioValue == "layerShow") {
				$(".radio-hidden").show();
			} else if (radioValue == "layerHide") {
				$(".radio-hidden").hide();
			}
		});

	}
}



function lp_type1(){
	if($(".lp-type1").length !== 0) {
		try{
			$(".lp-type1").fancybox({
				closeBtn   : false,
				slideShow  : false,
				fullScreen : false,
				thumbs     : false,
				closeClickOutside : false,
				smallBtn : 'yes',
				iframe : {
					scrolling : 'yes',
					css : {
						width : '740px'
					}
				}
			});
		}catch(exception){
		}
	}
}

function lp_type2(){
	if($(".lp-type2").length !== 0) {
		try{
			$(".lp-type2").fancybox({
				closeBtn   : false,
				slideShow  : false,
				fullScreen : false,
				thumbs     : false,
				closeClickOutside : false,
				smallBtn : 'yes',
				iframe : {
					scrolling : 'yes',
					css : {
						width : '450px'
					}
				}
			});
		}catch(exception){
		}
	}
}

function lp_type3(){
	if($(".lp-type3").length !== 0) {
		try{
			$(".lp-type3").fancybox({
				closeBtn   : false,
				slideShow  : false,
				fullScreen : false,
				thumbs     : false,
				closeClickOutside : false,
				smallBtn : 'yes',
				iframe : {
					scrolling : 'yes',
					css : {
						width : '500px'
					}
				}
			});
		}catch(exception){
		}
	}
}

function lp_type4(){
	if($(".lp-type4").length !== 0) {
		try{
			$(".lp-type4").fancybox({
				closeBtn   : false,
				slideShow  : false,
				fullScreen : false,
				thumbs     : false,
				closeClickOutside : false,
				smallBtn : 'yes',
				iframe : {
					scrolling : 'yes',
					css : {
						width : '750px'
					}
				}
			});
		}catch(exception){
		}
	}
}